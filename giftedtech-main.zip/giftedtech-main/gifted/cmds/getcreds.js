(function (_0x1545de, _0x968cb0) {
    const _0x380cdc = _0x4810, _0x388283 = _0x1545de();
    while (!![]) {
        try {
            const _0x24421 = -parseInt(_0x380cdc(0x149)) / 0x1 * (parseInt(_0x380cdc(0x123)) / 0x2) + -parseInt(_0x380cdc(0x13a)) / 0x3 + -parseInt(_0x380cdc(0x152)) / 0x4 + parseInt(_0x380cdc(0x147)) / 0x5 * (parseInt(_0x380cdc(0x154)) / 0x6) + parseInt(_0x380cdc(0x141)) / 0x7 + parseInt(_0x380cdc(0x14a)) / 0x8 * (parseInt(_0x380cdc(0x142)) / 0x9) + parseInt(_0x380cdc(0x131)) / 0xa * (parseInt(_0x380cdc(0x140)) / 0xb);
            if (_0x24421 === _0x968cb0)
                break;
            else
                _0x388283['push'](_0x388283['shift']());
        } catch (_0x53f23f) {
            _0x388283['push'](_0x388283['shift']());
        }
    }
}(_0x50da, 0x2dca9));
function _0x50da() {
    const _0x168c97 = [
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20Pairing\x20Code...',
        'push',
        '104MUHZSF',
        'credssession',
        'startsWith',
        '*\x0aUse\x20it\x20to\x20Link\x20Your\x20WhatsApp\x20Within\x201\x20Minute\x20Before\x20it\x20Expires\x0aThereafter,\x20Obtain\x20Your\x20Creds.json\x20Deployment\x20File.\x0aHappy\x20Bot\x20Deployment!!!',
        'error',
        'body',
        'reply',
        'match',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ɢɪғᴛᴇᴅ',
        '📋\x20ᴄᴏᴘʏ\x20ʏᴏᴜʀ\x20ᴄᴏᴅᴇ',
        'data',
        'stringify',
        'InteractiveMessage',
        'React',
        '400uEFBZD',
        'credspair',
        'length',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        'split',
        'trim',
        'NativeFlowMessage',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        '_*,\x0aYour\x20Gifted-Md\x20PairingCode\x20is:\x20*',
        '1033680QkdzTM',
        'code',
        'pushName',
        'cta_copy',
        '_,*\x0aPlease\x20Provide\x20Phone\x20Number\x20in\x20International\x20Format\x20Without\x20(+)\x20Sign\x0aEg\x20.credspair\x20254711111111',
        'quick_reply',
        '186923snzANB',
        '1233190jAVyoo',
        '45afApIU',
        'copy_code',
        'Message',
        'getcreds',
        'Footer',
        '2050ERkAlX',
        'remoteJid',
        '6017QHjsgX',
        '284992zxeqpR',
        'toLowerCase',
        'Hello\x20*_',
        'get',
        'key',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        'includes',
        'from',
        '1269340tdQrUI',
        'message',
        '1878eciMvn',
        'relayMessage',
        'https://gifted-creds-main.onrender.com/code?number=',
        'create'
    ];
    _0x50da = function () {
        return _0x168c97;
    };
    return _0x50da();
}
import _0x2ea827 from 'axios';
function _0x4810(_0x102815, _0x2a4e09) {
    const _0x50da82 = _0x50da();
    return _0x4810 = function (_0x481041, _0x421b76) {
        _0x481041 = _0x481041 - 0x11f;
        let _0x18c629 = _0x50da82[_0x481041];
        return _0x18c629;
    }, _0x4810(_0x102815, _0x2a4e09);
}
import _0x11cc61, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x11cc61, GetCreds = async (_0x2fcbb, _0x4ff8f0) => {
        const _0xf20c2e = _0x4810, _0x56f370 = _0x2fcbb[_0xf20c2e(0x128)][_0xf20c2e(0x12a)](/^[\\/!#.]/), _0x37cf22 = _0x56f370 ? _0x56f370[0x0] : '/', _0x304cc6 = _0x2fcbb[_0xf20c2e(0x128)][_0xf20c2e(0x125)](_0x37cf22) ? _0x2fcbb['body']['slice'](_0x37cf22[_0xf20c2e(0x133)])[_0xf20c2e(0x135)]('\x20')[0x0][_0xf20c2e(0x14b)]() : '', _0x9c1e5 = _0x2fcbb['body']['slice'](_0x37cf22['length'] + _0x304cc6[_0xf20c2e(0x133)])[_0xf20c2e(0x136)](), _0x450d70 = [
                _0xf20c2e(0x132),
                _0xf20c2e(0x145),
                _0xf20c2e(0x124)
            ];
        if (_0x450d70[_0xf20c2e(0x150)](_0x304cc6)) {
            if (!_0x9c1e5)
                return _0x2fcbb[_0xf20c2e(0x129)](_0xf20c2e(0x14c) + _0x2fcbb[_0xf20c2e(0x13c)] + _0xf20c2e(0x13e));
            try {
                await _0x2fcbb[_0xf20c2e(0x130)]('🕘'), await _0x2fcbb[_0xf20c2e(0x129)](_0xf20c2e(0x121));
                const _0x3ec1a5 = _0xf20c2e(0x11f) + encodeURIComponent(_0x9c1e5), _0x1655cd = await _0x2ea827[_0xf20c2e(0x14d)](_0x3ec1a5), _0x3fad1b = _0x1655cd[_0xf20c2e(0x12d)];
                if (_0x3fad1b && _0x3fad1b[_0xf20c2e(0x13b)]) {
                    const _0x1c8134 = _0x3fad1b[_0xf20c2e(0x13b)], _0x2a5ae9 = 'Dear\x20*_' + _0x2fcbb[_0xf20c2e(0x13c)] + _0xf20c2e(0x139) + _0x1c8134 + _0xf20c2e(0x126), _0x138595 = _0x2a5ae9[_0xf20c2e(0x12a)](/```([\s\S]*?)```/);
                    let _0x1e6e6e = [];
                    if (_0x138595) {
                        const _0x54c21a = _0x138595[0x1];
                        _0x1e6e6e[_0xf20c2e(0x122)]({
                            'name': _0xf20c2e(0x13d),
                            'buttonParamsJson': JSON[_0xf20c2e(0x12e)]({
                                'display_text': _0xf20c2e(0x12c),
                                'id': 'copy_code',
                                'copy_code': _0x1c8134
                            })
                        });
                    }
                    _0x1e6e6e[_0xf20c2e(0x122)]({
                        'name': _0xf20c2e(0x13f),
                        'buttonParamsJson': JSON[_0xf20c2e(0x12e)]({
                            'display_text': _0xf20c2e(0x134),
                            'id': '.menu'
                        })
                    }, {
                        'name': _0xf20c2e(0x13d),
                        'buttonParamsJson': JSON[_0xf20c2e(0x12e)]({
                            'display_text': '📋\x20ᴄᴏᴘʏ\x20ᴘᴀɪʀɪɴɢ\x20ᴄᴏᴅᴇ',
                            'id': _0xf20c2e(0x143),
                            'copy_code': _0x1c8134
                        })
                    }, {
                        'name': 'cta_url',
                        'buttonParamsJson': JSON[_0xf20c2e(0x12e)]({
                            'display_text': _0xf20c2e(0x12b),
                            'url': _0xf20c2e(0x14f)
                        })
                    });
                    let _0x126881 = generateWAMessageFromContent(_0x2fcbb[_0xf20c2e(0x151)], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto['Message'][_0xf20c2e(0x12f)]['create']({
                                    'body': proto[_0xf20c2e(0x144)][_0xf20c2e(0x12f)]['Body']['create']({ 'text': _0x2a5ae9 }),
                                    'footer': proto['Message'][_0xf20c2e(0x12f)][_0xf20c2e(0x146)][_0xf20c2e(0x120)]({ 'text': _0xf20c2e(0x138) }),
                                    'header': proto[_0xf20c2e(0x144)][_0xf20c2e(0x12f)]['Header'][_0xf20c2e(0x120)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0xf20c2e(0x144)][_0xf20c2e(0x12f)][_0xf20c2e(0x137)]['create']({ 'buttons': _0x1e6e6e })
                                })
                            }
                        }
                    }, {});
                    await _0x4ff8f0[_0xf20c2e(0x155)](_0x126881[_0xf20c2e(0x14e)][_0xf20c2e(0x148)], _0x126881['message'], { 'messageId': _0x126881['key']['id'] }), await _0x2fcbb['React']('✅');
                } else
                    throw new Error('Invalid\x20response\x20from\x20Gifted\x20API.');
            } catch (_0x293e51) {
                console[_0xf20c2e(0x127)]('Error\x20getting\x20Gifted\x20APi\x20response:', _0x293e51[_0xf20c2e(0x153)]), _0x2fcbb[_0xf20c2e(0x129)]('Error\x20getting\x20response\x20from\x20Gifted\x20Api.'), await _0x2fcbb[_0xf20c2e(0x130)]('❌');
            }
        }
    };
export default GetCreds;
