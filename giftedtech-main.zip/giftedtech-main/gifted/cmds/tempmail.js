(function (_0x756bd6, _0x341ca2) {
    const _0x364080 = _0x281d, _0x11289c = _0x756bd6();
    while (!![]) {
        try {
            const _0x1c520f = -parseInt(_0x364080(0xb5)) / 0x1 * (parseInt(_0x364080(0xad)) / 0x2) + -parseInt(_0x364080(0xa7)) / 0x3 + -parseInt(_0x364080(0x7d)) / 0x4 * (parseInt(_0x364080(0xa9)) / 0x5) + parseInt(_0x364080(0xb0)) / 0x6 * (-parseInt(_0x364080(0xa5)) / 0x7) + parseInt(_0x364080(0xb2)) / 0x8 + parseInt(_0x364080(0xa1)) / 0x9 * (parseInt(_0x364080(0xa4)) / 0xa) + parseInt(_0x364080(0x9a)) / 0xb * (parseInt(_0x364080(0x81)) / 0xc);
            if (_0x1c520f === _0x341ca2)
                break;
            else
                _0x11289c['push'](_0x11289c['shift']());
        } catch (_0x161ecd) {
            _0x11289c['push'](_0x11289c['shift']());
        }
    }
}(_0x47ff, 0xea73a));
import _0x3bfa16 from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x3bfa16;
function _0x281d(_0x5cfb4a, _0x84d80a) {
    const _0x47ffe8 = _0x47ff();
    return _0x281d = function (_0x281d7e, _0x19b87b) {
        _0x281d7e = _0x281d7e - 0x7b;
        let _0x446b6d = _0x47ffe8[_0x281d7e];
        return _0x446b6d;
    }, _0x281d(_0x5cfb4a, _0x84d80a);
}
function _0x47ff() {
    const _0x152e40 = [
        'key',
        '1837RADDaI',
        'reply',
        'copy_email',
        'ᴄᴏᴘʏ\x20ᴏᴛᴘ',
        'length',
        'https://tempmail.apinepdev.workers.dev/api/getmessage?email=',
        'check_inbox_',
        '99333AtGTFU',
        'date',
        'subject',
        '980qftlWq',
        '14otwzBu',
        'ᴘᴏᴡᴇʀᴇᴅ\x20ʙʏ\x20ɢɪғᴛᴇᴅ\x20ᴛᴇᴄʜ',
        '1129791KpZkCZ',
        'Header',
        '1570YCUWvf',
        'relayMessage',
        'NativeFlowMessage',
        'messages',
        '26762gLayCt',
        'create',
        'quick_reply',
        '1646466ikIXLp',
        'Footer',
        '1572696NFPoeR',
        'match',
        'Message',
        '29yaRuuX',
        '𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐓𝐄𝐌𝐏𝐌𝐀𝐈𝐋\x20𝐈𝐍𝐁𝐎𝐗',
        'message',
        'email',
        '*ɢᴇɴᴇʀᴀᴛᴇᴅ\x20ᴇᴍᴀɪʟ:*\x0a\x20',
        'error',
        'cta_copy',
        'React',
        'https://tempmail.apinepdev.workers.dev/api/gen',
        'slice',
        'forEach',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'templateButtonReplyMessage',
        '484pAHpoF',
        'remoteJid',
        'startsWith',
        'copy_otp',
        '74268bDFiBT',
        'toLocaleString',
        '\x0a*Date:*\x20',
        'toLowerCase',
        'stringify',
        'body',
        'textBody',
        '*ɪɴʙᴏx\x20ᴍᴇssᴀɢᴇs:*\x0a\x0a',
        'ᴄʜᴇᴄᴋ\x20ɪɴʙᴏx\x20ᴀɢᴀɪɴ',
        'json',
        'parse',
        'Error\x20processing\x20your\x20request.',
        'nativeFlowResponseMessage',
        'Error\x20processing\x20your\x20request:',
        '\x0a*Message:*\x20',
        'InteractiveMessage',
        'push',
        'from',
        'Body',
        'interactiveResponseMessage',
        'sender',
        '\x0a*Subject:*\x20',
        'selectedId',
        '*𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20𝐓𝐄𝐌𝐏𝐌𝐀𝐈𝐋\x20𝐒𝐘𝐒𝐓𝐄𝐌*'
    ];
    _0x47ff = function () {
        return _0x152e40;
    };
    return _0x47ff();
}
import _0x6fe722 from 'node-fetch';
const tempMailCommand = async (_0x2034c1, _0x346f31) => {
    const _0x1af24a = _0x281d, _0x3d56ab = _0x2034c1[_0x1af24a(0x86)][_0x1af24a(0xb3)](/^[\\/!#.]/), _0x373705 = _0x3d56ab ? _0x3d56ab[0x0] : '/', _0x4bca59 = _0x2034c1[_0x1af24a(0x86)][_0x1af24a(0x7f)](_0x373705) ? _0x2034c1[_0x1af24a(0x86)][_0x1af24a(0xbe)](_0x373705[_0x1af24a(0x9e)])['split']('\x20')[0x0][_0x1af24a(0x84)]() : '';
    let _0x3e0edc;
    const _0xa1dcf4 = _0x2034c1?.['message']?.[_0x1af24a(0x7c)]?.[_0x1af24a(0x97)], _0x56b62a = _0x2034c1?.[_0x1af24a(0xb7)]?.[_0x1af24a(0x94)];
    if (_0x56b62a) {
        const _0x4ef08c = _0x56b62a[_0x1af24a(0x8d)]?.['paramsJson'];
        if (_0x4ef08c) {
            const _0x54da67 = JSON[_0x1af24a(0x8b)](_0x4ef08c);
            _0x3e0edc = _0x54da67['id'];
        }
    }
    const _0x2f0fd0 = _0x3e0edc || _0xa1dcf4;
    if (_0x4bca59 === 'tempmail')
        try {
            await _0x2034c1[_0x1af24a(0xbc)]('🕘');
            const _0x3fb7de = await _0x6fe722(_0x1af24a(0xbd)), _0x2da140 = await _0x3fb7de[_0x1af24a(0x8a)]();
            if (!_0x2da140[_0x1af24a(0xb8)]) {
                _0x2034c1[_0x1af24a(0x9b)]('Failed\x20to\x20generate\x20temporary\x20email.'), await _0x2034c1['React']('❌');
                return;
            }
            const _0x4edfda = _0x2da140[_0x1af24a(0xb8)], _0x5cadb7 = [
                    {
                        'name': _0x1af24a(0xbb),
                        'buttonParamsJson': JSON[_0x1af24a(0x85)]({
                            'display_text': 'ᴄᴏᴘʏ\x20ᴇᴍᴀɪʟ',
                            'id': _0x1af24a(0x9c),
                            'copy_code': _0x4edfda
                        })
                    },
                    {
                        'name': _0x1af24a(0xaf),
                        'buttonParamsJson': JSON[_0x1af24a(0x85)]({
                            'display_text': 'ᴄʜᴇᴄᴋ\x20ɪɴʙᴏx',
                            'id': _0x1af24a(0xa0) + _0x4edfda
                        })
                    }
                ], _0x3222a8 = generateWAMessageFromContent(_0x2034c1[_0x1af24a(0x92)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto['Message'][_0x1af24a(0x90)][_0x1af24a(0xae)]({
                                'body': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)][_0x1af24a(0x93)][_0x1af24a(0xae)]({ 'text': _0x1af24a(0xb9) + _0x4edfda }),
                                'footer': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)][_0x1af24a(0xb1)]['create']({ 'text': _0x1af24a(0x7b) }),
                                'header': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)][_0x1af24a(0xa8)]['create']({
                                    'title': _0x1af24a(0x98),
                                    'gifPlayback': !![],
                                    'subtitle': _0x1af24a(0xa6),
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto['Message'][_0x1af24a(0x90)]['NativeFlowMessage'][_0x1af24a(0xae)]({ 'buttons': _0x5cadb7 }),
                                'contextInfo': {
                                    'mentionedJid': [_0x2034c1[_0x1af24a(0x95)]],
                                    'forwardingScore': 0x270f,
                                    'isForwarded': ![]
                                }
                            })
                        }
                    }
                }, {}), _0x265570 = await _0x346f31['relayMessage'](_0x3222a8['key'][_0x1af24a(0x7e)], _0x3222a8['message'], { 'messageId': _0x3222a8[_0x1af24a(0x99)]['id'] });
            await _0x2034c1[_0x1af24a(0xbc)]('✅');
        } catch (_0x7b6175) {
            console[_0x1af24a(0xba)](_0x1af24a(0x8e), _0x7b6175), _0x2034c1[_0x1af24a(0x9b)](_0x1af24a(0x8c)), await _0x2034c1[_0x1af24a(0xbc)]('❌');
        }
    else {
        if (_0x2f0fd0 && _0x2f0fd0[_0x1af24a(0x7f)](_0x1af24a(0xa0))) {
            const _0x4f368d = _0x2f0fd0[_0x1af24a(0xbe)](_0x1af24a(0xa0)[_0x1af24a(0x9e)]);
            try {
                await _0x2034c1[_0x1af24a(0xbc)]('🕘');
                const _0x2a8bc9 = await _0x6fe722(_0x1af24a(0x9f) + _0x4f368d), _0x286c8a = await _0x2a8bc9[_0x1af24a(0x8a)]();
                let _0x27a378, _0x505d25 = [];
                _0x286c8a[_0x1af24a(0xac)] && _0x286c8a[_0x1af24a(0xac)][_0x1af24a(0x9e)] > 0x0 ? (_0x27a378 = _0x1af24a(0x88), _0x286c8a[_0x1af24a(0xac)][_0x1af24a(0xbf)]((_0x5176f2, _0x142b43) => {
                    const _0x3c2679 = _0x1af24a, _0x43c179 = JSON[_0x3c2679(0x8b)](_0x5176f2['message']);
                    _0x27a378 += _0x142b43 + 0x1 + '.\x20*From:*\x20' + _0x5176f2[_0x3c2679(0x95)] + _0x3c2679(0x96) + _0x5176f2[_0x3c2679(0xa3)] + _0x3c2679(0x83) + new Date(_0x43c179[_0x3c2679(0xa2)])[_0x3c2679(0x82)]() + _0x3c2679(0x8f) + _0x43c179['body'] + '\x0a\x0a';
                    const _0x4f5660 = _0x43c179[_0x3c2679(0x87)] || '', _0x21c469 = _0x4f5660['match'](/\b\d{4,6}\b/);
                    _0x21c469 && _0x505d25[_0x3c2679(0x91)]({
                        'name': _0x3c2679(0xbb),
                        'buttonParamsJson': JSON[_0x3c2679(0x85)]({
                            'display_text': _0x3c2679(0x9d),
                            'id': _0x3c2679(0x80),
                            'copy_code': _0x21c469[0x0]
                        })
                    });
                })) : _0x27a378 = 'No\x20messages\x20found\x20in\x20the\x20inbox.';
                _0x505d25[_0x1af24a(0x91)]({
                    'name': _0x1af24a(0xaf),
                    'buttonParamsJson': JSON['stringify']({
                        'display_text': _0x1af24a(0x89),
                        'id': _0x1af24a(0xa0) + _0x4f368d
                    })
                });
                const _0x5729b3 = generateWAMessageFromContent(_0x2034c1[_0x1af24a(0x92)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)][_0x1af24a(0xae)]({
                                'body': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)]['Body'][_0x1af24a(0xae)]({ 'text': _0x27a378 }),
                                'footer': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)][_0x1af24a(0xb1)][_0x1af24a(0xae)]({ 'text': _0x1af24a(0x7b) }),
                                'header': proto[_0x1af24a(0xb4)][_0x1af24a(0x90)]['Header'][_0x1af24a(0xae)]({
                                    'title': _0x1af24a(0xb6),
                                    'gifPlayback': !![],
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto['Message'][_0x1af24a(0x90)][_0x1af24a(0xab)][_0x1af24a(0xae)]({ 'buttons': _0x505d25 }),
                                'contextInfo': {
                                    'mentionedJid': [_0x2034c1[_0x1af24a(0x95)]],
                                    'forwardingScore': 0x270f,
                                    'isForwarded': ![]
                                }
                            })
                        }
                    }
                }, {});
                await _0x346f31[_0x1af24a(0xaa)](_0x5729b3[_0x1af24a(0x99)]['remoteJid'], _0x5729b3[_0x1af24a(0xb7)], { 'messageId': _0x5729b3[_0x1af24a(0x99)]['id'] }), await _0x2034c1['React']('✅');
            } catch (_0x51b864) {
                console[_0x1af24a(0xba)]('Error\x20processing\x20your\x20request:', _0x51b864), _0x2034c1[_0x1af24a(0x9b)](_0x1af24a(0x8c)), await _0x2034c1[_0x1af24a(0xbc)]('❌');
            }
        } else {
        }
    }
};
export default tempMailCommand;
