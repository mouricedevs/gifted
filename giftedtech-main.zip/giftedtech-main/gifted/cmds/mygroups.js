(function (_0x4a432c, _0x5a3e4a) {
    const _0x58010e = _0x5d46, _0x3086df = _0x4a432c();
    while (!![]) {
        try {
            const _0x3dff2c = -parseInt(_0x58010e(0x1de)) / 0x1 * (parseInt(_0x58010e(0x1d4)) / 0x2) + parseInt(_0x58010e(0x1fc)) / 0x3 + -parseInt(_0x58010e(0x1f1)) / 0x4 + parseInt(_0x58010e(0x1e0)) / 0x5 + -parseInt(_0x58010e(0x1f2)) / 0x6 * (-parseInt(_0x58010e(0x1e3)) / 0x7) + parseInt(_0x58010e(0x1fb)) / 0x8 + -parseInt(_0x58010e(0x1f5)) / 0x9 * (-parseInt(_0x58010e(0x1e7)) / 0xa);
            if (_0x3dff2c === _0x5a3e4a)
                break;
            else
                _0x3086df['push'](_0x3086df['shift']());
        } catch (_0x37dde2) {
            _0x3086df['push'](_0x3086df['shift']());
        }
    }
}(_0x312a, 0xe89c9));
function _0x5d46(_0x2b1f80, _0x568684) {
    const _0x312acb = _0x312a();
    return _0x5d46 = function (_0x5d464c, _0x5b8a8d) {
        _0x5d464c = _0x5d464c - 0x1d4;
        let _0x409b82 = _0x312acb[_0x5d464c];
        return _0x409b82;
    }, _0x5d46(_0x2b1f80, _0x568684);
}
const MyGrps = async (_0x2ed4a6, _0x497772) => {
    const _0x4753c0 = _0x5d46, _0x5e24c2 = _0x2ed4a6[_0x4753c0(0x1da)][_0x4753c0(0x1ea)](/^[\\/!#.]/), _0x4a0deb = _0x5e24c2 ? _0x5e24c2[0x0] : '/', _0x1d3ef0 = _0x2ed4a6[_0x4753c0(0x1da)][_0x4753c0(0x1ee)](_0x4a0deb) ? _0x2ed4a6['body'][_0x4753c0(0x1d9)](_0x4a0deb['length'])[_0x4753c0(0x1f8)]('\x20')[0x0][_0x4753c0(0x1e2)]() : '', _0x486036 = _0x2ed4a6[_0x4753c0(0x1da)][_0x4753c0(0x1d9)](_0x4a0deb['length'] + _0x1d3ef0[_0x4753c0(0x1d5)])['trim'](), _0x1c6499 = [
            _0x4753c0(0x1f7),
            _0x4753c0(0x1f6),
            _0x4753c0(0x1eb),
            _0x4753c0(0x1ed),
            _0x4753c0(0x1f3)
        ];
    if (_0x1c6499[_0x4753c0(0x1e6)](_0x1d3ef0))
        try {
            await _0x2ed4a6['React']('🕘');
            let _0xcea843 = await _0x497772[_0x4753c0(0x1e4)]();
            if (!_0xcea843)
                throw new Error(_0x4753c0(0x1dd));
            let _0x4f8648 = Object[_0x4753c0(0x1ef)](_0xcea843)[_0x4753c0(0x1d9)](0x0)[_0x4753c0(0x1df)](_0x1cd427 => _0x1cd427[0x1]), _0x68c456 = _0x4f8648['map'](_0x1d9a82 => _0x1d9a82['id']), _0x87a4c8 = '*' + _0x2ed4a6[_0x4753c0(0x1d6)] + _0x4753c0(0x1e1);
            await _0x2ed4a6[_0x4753c0(0x1d7)](_0x4753c0(0x1dc) + _0x2ed4a6[_0x4753c0(0x1d6)] + _0x4753c0(0x1f9) + _0x68c456['length'] + _0x4753c0(0x1fa));
            for (let _0x5505f1 of _0x68c456) {
                try {
                    let _0x31ccef = await _0x497772['groupMetadata'](_0x5505f1);
                    _0x87a4c8 += '*GROUP\x20NAME:*-\x20' + _0x31ccef['subject'] + '\x0a', _0x87a4c8 += _0x4753c0(0x1d8) + _0x31ccef[_0x4753c0(0x1f4)][_0x4753c0(0x1d5)] + '\x0a', _0x87a4c8 += _0x4753c0(0x1ec) + _0x5505f1 + '\x0a\x0a';
                } catch (_0x1fac36) {
                    console[_0x4753c0(0x1db)](_0x4753c0(0x1e8) + _0x5505f1 + ':', _0x1fac36), _0x87a4c8 += _0x4753c0(0x1ec) + _0x5505f1 + _0x4753c0(0x1e5);
                }
            }
            await _0x2ed4a6[_0x4753c0(0x1d7)](_0x87a4c8), await _0x2ed4a6['React']('✅');
        } catch (_0x4a0d72) {
            console[_0x4753c0(0x1db)]('Error\x20from\x20Gifted\x20API:', _0x4a0d72), await _0x497772[_0x4753c0(0x1e9)](_0x2ed4a6['from'], { 'text': _0x4753c0(0x1f0) });
        }
};
function _0x312a() {
    const _0x326667 = [
        'mygroups',
        '*GROUP\x20ID:*-\x20',
        'mygrps',
        'startsWith',
        'entries',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        '2671448NXwzTy',
        '8980770TVrsQH',
        'my-groups',
        'participants',
        '940959iAwpOW',
        'grps',
        'groups',
        'split',
        ',*_\x20You\x20are\x20currently\x20in\x20',
        '\x20groups.\x20Gifted\x20Md\x20will\x20send\x20that\x20list\x20in\x20a\x20moment...',
        '5312440XvnMuA',
        '2342244hiiLQQ',
        '628944BBqQgE',
        'length',
        'pushName',
        'reply',
        '*MEMBERS:*-\x20',
        'slice',
        'body',
        'error',
        'Hello\x20_*',
        'Failed\x20to\x20fetch\x20groups',
        '5zlUNJF',
        'map',
        '734250cePtZG',
        '\x20GROUPS:*\x0a\x0a',
        'toLowerCase',
        '7CdvZAr',
        'groupFetchAllParticipating',
        '\x20(Failed\x20to\x20fetch\x20metadata)\x0a\x0a',
        'includes',
        '10kMaTwX',
        'Failed\x20to\x20fetch\x20metadata\x20for\x20group\x20',
        'sendMessage',
        'match'
    ];
    _0x312a = function () {
        return _0x326667;
    };
    return _0x312a();
}
export default MyGrps;
