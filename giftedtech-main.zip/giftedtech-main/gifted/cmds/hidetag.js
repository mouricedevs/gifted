(function (_0x18ac0b, _0x4c353a) {
    const _0x3910c2 = _0x4a6b, _0x283320 = _0x18ac0b();
    while (!![]) {
        try {
            const _0x185a05 = parseInt(_0x3910c2(0x189)) / 0x1 + parseInt(_0x3910c2(0x182)) / 0x2 + -parseInt(_0x3910c2(0x17e)) / 0x3 + -parseInt(_0x3910c2(0x172)) / 0x4 + -parseInt(_0x3910c2(0x180)) / 0x5 * (-parseInt(_0x3910c2(0x190)) / 0x6) + -parseInt(_0x3910c2(0x173)) / 0x7 * (-parseInt(_0x3910c2(0x176)) / 0x8) + -parseInt(_0x3910c2(0x16d)) / 0x9 * (-parseInt(_0x3910c2(0x170)) / 0xa);
            if (_0x185a05 === _0x4c353a)
                break;
            else
                _0x283320['push'](_0x283320['shift']());
        } catch (_0x48db42) {
            _0x283320['push'](_0x283320['shift']());
        }
    }
}(_0x1730, 0xe8ccc));
function _0x4a6b(_0xab4ef0, _0x2ff039) {
    const _0x1730f7 = _0x1730();
    return _0x4a6b = function (_0x4a6bdc, _0x162ede) {
        _0x4a6bdc = _0x4a6bdc - 0x16d;
        let _0x234276 = _0x1730f7[_0x4a6bdc];
        return _0x234276;
    }, _0x4a6b(_0xab4ef0, _0x2ff039);
}
const tagall = async (_0x2b0a6a, _0x1f8c12) => {
    const _0xfbef0d = _0x4a6b;
    try {
        const _0x56a254 = await _0x1f8c12[_0xfbef0d(0x18f)](_0x1f8c12[_0xfbef0d(0x17f)]['id']), _0x4e435e = _0x2b0a6a[_0xfbef0d(0x188)][_0xfbef0d(0x174)](/^[\\/!#.]/), _0x1749f9 = _0x4e435e ? _0x4e435e[0x0] : '/', _0x54f5ca = _0x2b0a6a[_0xfbef0d(0x188)][_0xfbef0d(0x181)](_0x1749f9) ? _0x2b0a6a[_0xfbef0d(0x188)][_0xfbef0d(0x18c)](_0x1749f9[_0xfbef0d(0x175)])[_0xfbef0d(0x17c)]('\x20')[0x0][_0xfbef0d(0x16e)]() : '', _0x5bedda = [
                _0xfbef0d(0x17a),
                _0xfbef0d(0x185)
            ];
        if (!_0x5bedda[_0xfbef0d(0x177)](_0x54f5ca))
            return;
        const _0x320829 = await _0x1f8c12[_0xfbef0d(0x18b)](_0x2b0a6a[_0xfbef0d(0x16f)]), _0x420742 = _0x320829[_0xfbef0d(0x179)], _0x58c01b = _0x420742[_0xfbef0d(0x18a)](_0x27e96c => _0x27e96c['id'] === _0x56a254)?.['admin'], _0x4e5886 = _0x420742[_0xfbef0d(0x18a)](_0x4f5a8 => _0x4f5a8['id'] === _0x2b0a6a['sender'])?.[_0xfbef0d(0x184)];
        if (!_0x2b0a6a[_0xfbef0d(0x186)])
            return _0x2b0a6a[_0xfbef0d(0x178)](_0xfbef0d(0x171));
        if (!_0x58c01b)
            return _0x2b0a6a['reply']('*📛\x20BOT\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*');
        if (!_0x4e5886)
            return _0x2b0a6a[_0xfbef0d(0x178)](_0xfbef0d(0x17d));
        let _0xba290b = '乂\x20*Attention\x20Everyone*\x20乂\x0a\x0a*Message:*\x20' + (_0x2b0a6a[_0xfbef0d(0x188)][_0xfbef0d(0x18c)](_0x1749f9[_0xfbef0d(0x175)] + _0x54f5ca['length'])['trim']() || 'no\x20message') + '\x0a\x0a';
        for (let _0x12e591 of _0x420742) {
            _0xba290b += _0xfbef0d(0x183) + _0x12e591['id'][_0xfbef0d(0x17c)]('@')[0x0] + '\x0a';
        }
        _0x1f8c12['sendMessage'](_0x2b0a6a[_0xfbef0d(0x16f)], {
            'text': _0x2b0a6a[_0xfbef0d(0x18e)]['text'] ? _0x2b0a6a[_0xfbef0d(0x18e)][_0xfbef0d(0x17b)] : '',
            'mentions': _0x420742[_0xfbef0d(0x18d)](_0x9fb858 => _0x9fb858['id'])
        }, { 'quoted': _0x2b0a6a });
    } catch (_0x1c83a6) {
        console['error']('Error:', _0x1c83a6), await _0x2b0a6a[_0xfbef0d(0x178)](_0xfbef0d(0x187));
    }
};
export default tagall;
function _0x1730() {
    const _0xe24c0c = [
        '1890408ktBQAO',
        'user',
        '6380pqzgPr',
        'startsWith',
        '2028938sWqZZb',
        '❒\x20@',
        'admin',
        'untag',
        'isGroup',
        'An\x20error\x20occurred\x20while\x20processing\x20the\x20command.',
        'body',
        '985699MuJUpz',
        'find',
        'groupMetadata',
        'slice',
        'map',
        'quoted',
        'decodeJid',
        '426PPQklw',
        '369kNqsTv',
        'toLowerCase',
        'from',
        '58070TBlDhl',
        '*📛\x20THIS\x20COMMAND\x20CAN\x20ONLY\x20BE\x20USED\x20IN\x20GROUPS*',
        '7598664nxUweB',
        '152481WOCLMA',
        'match',
        'length',
        '424CdJSIY',
        'includes',
        'reply',
        'participants',
        'hidetag',
        'text',
        'split',
        '*📛\x20YOU\x20MUST\x20BE\x20AN\x20ADMIN\x20TO\x20USE\x20THIS\x20COMMAND*'
    ];
    _0x1730 = function () {
        return _0xe24c0c;
    };
    return _0x1730();
}
