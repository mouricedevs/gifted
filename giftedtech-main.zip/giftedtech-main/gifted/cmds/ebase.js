// GIFTED-MD //
function gifted_0x3d43(_0x5810ee, _0x22b86d) {
    const _0xd1079a = gifted_0xd107();
    return gifted_0x3d43 = function (_0x3d4340, _0x4481f7) {
        _0x3d4340 = _0x3d4340 - 0x67;
        let _0x451c02 = _0xd1079a[_0x3d4340];
        return _0x451c02;
    }, gifted_0x3d43(_0x5810ee, _0x22b86d);
}
(function (_0x4b5182, _0x213cb5) {
    const _0x333916 = gifted_0x3d43, _0x1d8d8f = _0x4b5182();
    while (!![]) {
        try {
            const _0x1fe948 = -parseInt(_0x333916(0x6b)) / 0x1 * (-parseInt(_0x333916(0x6e)) / 0x2) + -parseInt(_0x333916(0x79)) / 0x3 * (-parseInt(_0x333916(0x90)) / 0x4) + -parseInt(_0x333916(0x88)) / 0x5 * (parseInt(_0x333916(0x92)) / 0x6) + -parseInt(_0x333916(0x7c)) / 0x7 * (-parseInt(_0x333916(0x77)) / 0x8) + -parseInt(_0x333916(0x93)) / 0x9 + parseInt(_0x333916(0x6f)) / 0xa + parseInt(_0x333916(0x85)) / 0xb;
            if (_0x1fe948 === _0x213cb5)
                break;
            else
                _0x1d8d8f['push'](_0x1d8d8f['shift']());
        } catch (_0x5b2dc1) {
            _0x1d8d8f['push'](_0x1d8d8f['shift']());
        }
    }
}(gifted_0xd107, 0xddcbc));
function gifted_0xd107() {
    const _0xb0f733 = [
        'slice',
        'Footer',
        'toLowerCase',
        'Error\x20getting\x20GPT\x20response:',
        'cta_copy',
        '8MUrLQr',
        'trim',
        '14295TxKWmM',
        'error',
        'Error\x20getting\x20response\x20from\x20GPT.',
        '3101224VJZDnP',
        'reply',
        'Message',
        'Header',
        'data',
        'NativeFlowMessage',
        '&apikey=',
        'length',
        'startsWith',
        '1591249isywkx',
        'relayMessage',
        'result',
        '65mfnOpC',
        'key',
        'copy_code',
        'sendMessage',
        'Copy\x20Your\x20Code',
        'includes',
        '_,*\x0aPlease\x20Provide\x20Me\x20a\x20text\x20to\x20Encrypt.',
        'body',
        '44PapJMk',
        'React',
        '682314EGPBaa',
        '9123759CErjPy',
        'InteractiveMessage',
        'from',
        'Hello\x20*_',
        'message',
        'Invalid\x20response\x20from\x20the\x20GPT\x20API.',
        '7727KQdHQV',
        'pushName',
        'match',
        '342YMMoeJ',
        '14391510TPLrzi',
        'A\x20moment...',
        'create'
    ];
    gifted_0xd107 = function () {
        return _0xb0f733;
    };
    return gifted_0xd107();
}
import gifted_0x55d584 from 'axios';
import gifted_0x32c317, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = gifted_0x32c317, Ebase = async (_0x51b4db, _0x481271) => {
        const _0x633706 = gifted_0x3d43, _0x22fdfb = _0x51b4db['body'][_0x633706(0x6d)](/^[\\/!#.]/), _0x4be40b = _0x22fdfb ? _0x22fdfb[0x0] : '/', _0x1c97f = 'https://giftedapis.us.kg', _0x4dc476 = '_0x5aff35,_0x187643', _0x282487 = _0x51b4db[_0x633706(0x8f)][_0x633706(0x84)](_0x4be40b) ? _0x51b4db['body'][_0x633706(0x72)](_0x4be40b[_0x633706(0x83)])['split']('\x20')[0x0][_0x633706(0x74)]() : '', _0x37d765 = _0x51b4db[_0x633706(0x8f)][_0x633706(0x72)](_0x4be40b[_0x633706(0x83)] + _0x282487[_0x633706(0x83)])[_0x633706(0x78)](), _0x6e50cd = ['ebase'];
        if (_0x6e50cd[_0x633706(0x8d)](_0x282487)) {
            if (!_0x37d765)
                return _0x51b4db[_0x633706(0x7d)](_0x633706(0x68) + _0x51b4db[_0x633706(0x6c)] + _0x633706(0x8e));
            try {
                await _0x51b4db[_0x633706(0x91)]('🕘'), await _0x51b4db[_0x633706(0x7d)](_0x633706(0x70));
                let _0x3643b5 = _0x4dc476;
                const _0x106710 = _0x1c97f + '/api/tools/ebase?query=' + encodeURIComponent(_0x37d765) + _0x633706(0x82) + _0x3643b5, _0x352b8e = await gifted_0x55d584['get'](_0x106710), _0x4d3efe = _0x352b8e[_0x633706(0x80)];
                if (_0x4d3efe && _0x4d3efe[_0x633706(0x87)]) {
                    const _0x2a3af2 = _0x4d3efe[_0x633706(0x87)], _0x4d3e94 = _0x2a3af2['match'](/```([\s\S]*?)```/);
                    if (_0x4d3e94) {
                        const _0x24fd32 = _0x4d3e94[0x1];
                        let _0x54651a = generateWAMessageFromContent(_0x51b4db[_0x633706(0x67)], {
                            'viewOnceMessage': {
                                'message': {
                                    'messageContextInfo': {
                                        'deviceListMetadata': {},
                                        'deviceListMetadataVersion': 0x2
                                    },
                                    'interactiveMessage': proto[_0x633706(0x7e)][_0x633706(0x94)]['create']({
                                        'body': proto['Message']['InteractiveMessage']['Body'][_0x633706(0x71)]({ 'text': _0x2a3af2 }),
                                        'footer': proto[_0x633706(0x7e)][_0x633706(0x94)][_0x633706(0x73)]['create']({ 'text': '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*' }),
                                        'header': proto['Message'][_0x633706(0x94)][_0x633706(0x7f)][_0x633706(0x71)]({
                                            'title': '',
                                            'subtitle': '',
                                            'hasMediaAttachment': ![]
                                        }),
                                        'nativeFlowMessage': proto[_0x633706(0x7e)][_0x633706(0x94)][_0x633706(0x81)][_0x633706(0x71)]({
                                            'buttons': [{
                                                    'name': _0x633706(0x76),
                                                    'buttonParamsJson': JSON['stringify']({
                                                        'display_text': _0x633706(0x8c),
                                                        'id': _0x633706(0x8a),
                                                        'copy_code': _0x24fd32
                                                    })
                                                }]
                                        })
                                    })
                                }
                            }
                        }, {});
                        await _0x481271[_0x633706(0x86)](_0x54651a[_0x633706(0x89)]['remoteJid'], _0x54651a[_0x633706(0x69)], { 'messageId': _0x54651a[_0x633706(0x89)]['id'] });
                    } else
                        await _0x481271[_0x633706(0x8b)](_0x51b4db[_0x633706(0x67)], { 'text': _0x2a3af2 }, { 'quoted': _0x51b4db });
                    await _0x51b4db[_0x633706(0x91)]('✅');
                } else
                    throw new Error(_0x633706(0x6a));
            } catch (_0x3ae5cd) {
                console[_0x633706(0x7a)](_0x633706(0x75), _0x3ae5cd[_0x633706(0x69)]), _0x51b4db[_0x633706(0x7d)](_0x633706(0x7b)), await _0x51b4db[_0x633706(0x91)]('❌');
            }
        }
    };
export default Ebase;

// GIFTED-MD //
