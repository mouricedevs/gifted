// GIFTED-MD //
function gifted_0x2082(_0x410589, _0x460d0c) {
    const _0x509164 = gifted_0x5091();
    return gifted_0x2082 = function (_0x208256, _0x265194) {
        _0x208256 = _0x208256 - 0x155;
        let _0x35d3ee = _0x509164[_0x208256];
        return _0x35d3ee;
    }, gifted_0x2082(_0x410589, _0x460d0c);
}
function gifted_0x5091() {
    const _0x3a7b23 = [
        'result',
        '6NHzIEb',
        'Invalid\x20response\x20from\x20the\x20GPT\x20API.',
        'quick_reply',
        'Footer',
        'length',
        'push',
        'cta_copy',
        'Hello\x20*_',
        'toLowerCase',
        '15287000foJVEd',
        'relayMessage',
        '349716KkmeyK',
        'stringify',
        'Error\x20getting\x20GPT\x20response:',
        '963316GoUtAm',
        'split',
        '_0x5aff35,_0x187643',
        'https://giftedapis.us.kg',
        'startsWith',
        '257442IcDcxU',
        'reply',
        'includes',
        'match',
        'trim',
        '_,*\x0a\x20Gifted\x20Gemini\x20Ai\x20Here.\x0a\x20Please\x20Ask\x20Me\x20a\x20Question.',
        'message',
        'https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l',
        'pushName',
        'geminiai',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ\x20ɢɪғᴛᴇᴅ',
        'React',
        'create',
        'A\x20moment,\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20Gemini\x20Request...',
        'NativeFlowMessage',
        '3453030KIpKDF',
        'remoteJid',
        'Body',
        'Header',
        'key',
        'Error\x20getting\x20response\x20from\x20GPT.',
        '&apikey=',
        'cta_url',
        'body',
        '1751020UUqArN',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        '2453945HIcUgu',
        'slice',
        '/api/ai/geminiai?q=',
        '📋\x20ᴄᴏᴘʏ\x20ɢᴇɴᴇʀᴀᴛᴇᴅ\x20ᴄᴏᴅᴇ',
        'copy_code',
        'InteractiveMessage',
        'error',
        'Message'
    ];
    gifted_0x5091 = function () {
        return _0x3a7b23;
    };
    return gifted_0x5091();
}
(function (_0x1d572b, _0x3a77c9) {
    const _0x2d1308 = gifted_0x2082, _0x593006 = _0x1d572b();
    while (!![]) {
        try {
            const _0x31c77b = parseInt(_0x2d1308(0x15d)) / 0x1 + parseInt(_0x2d1308(0x160)) / 0x2 + -parseInt(_0x2d1308(0x165)) / 0x3 + parseInt(_0x2d1308(0x17d)) / 0x4 + parseInt(_0x2d1308(0x17f)) / 0x5 * (parseInt(_0x2d1308(0x188)) / 0x6) + parseInt(_0x2d1308(0x174)) / 0x7 + -parseInt(_0x2d1308(0x15b)) / 0x8;
            if (_0x31c77b === _0x3a77c9)
                break;
            else
                _0x593006['push'](_0x593006['shift']());
        } catch (_0x4b77cc) {
            _0x593006['push'](_0x593006['shift']());
        }
    }
}(gifted_0x5091, 0x3ea07));
import gifted_0x8682bd from 'axios';
import gifted_0x1cd9c9, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = gifted_0x1cd9c9, geminiResponse = async (_0x3459ea, _0x5b5451) => {
        const _0x19cded = gifted_0x2082, _0x45d8f9 = _0x3459ea[_0x19cded(0x17c)][_0x19cded(0x168)](/^[\\/!#.]/), _0x3d8040 = _0x45d8f9 ? _0x45d8f9[0x0] : '/', _0x56ef5d = _0x19cded(0x163), _0x54f241 = _0x19cded(0x162), _0x341e32 = _0x3459ea[_0x19cded(0x17c)][_0x19cded(0x164)](_0x3d8040) ? _0x3459ea[_0x19cded(0x17c)][_0x19cded(0x180)](_0x3d8040[_0x19cded(0x156)])[_0x19cded(0x161)]('\x20')[0x0][_0x19cded(0x15a)]() : '', _0x59bb52 = _0x3459ea[_0x19cded(0x17c)][_0x19cded(0x180)](_0x3d8040[_0x19cded(0x156)] + _0x341e32[_0x19cded(0x156)])[_0x19cded(0x169)](), _0x5785c1 = [
                'gemini',
                _0x19cded(0x16e)
            ];
        if (_0x5785c1[_0x19cded(0x167)](_0x341e32)) {
            if (!_0x59bb52)
                return _0x3459ea[_0x19cded(0x166)](_0x19cded(0x159) + _0x3459ea[_0x19cded(0x16d)] + _0x19cded(0x16a));
            try {
                await _0x3459ea[_0x19cded(0x170)]('🕘'), await _0x3459ea['reply'](_0x19cded(0x172));
                let _0x1e6d16 = _0x54f241;
                const _0x109948 = _0x56ef5d + _0x19cded(0x181) + encodeURIComponent(_0x59bb52) + _0x19cded(0x17a) + _0x1e6d16, _0x4f87dc = await gifted_0x8682bd['get'](_0x109948), _0x4a48f9 = _0x4f87dc['data'];
                if (_0x4a48f9 && _0x4a48f9[_0x19cded(0x187)]) {
                    const _0x53c244 = _0x4a48f9[_0x19cded(0x187)], _0x13161b = _0x53c244 + '\x0a\x0a', _0x49d2a3 = _0x53c244[_0x19cded(0x168)](/```([\s\S]*?)```/);
                    let _0x1b6d31 = [];
                    if (_0x49d2a3) {
                        const _0x1b9433 = _0x49d2a3[0x1];
                        _0x1b6d31['push']({
                            'name': _0x19cded(0x158),
                            'buttonParamsJson': JSON[_0x19cded(0x15e)]({
                                'display_text': _0x19cded(0x182),
                                'id': _0x19cded(0x183),
                                'copy_code': _0x1b9433
                            })
                        });
                    }
                    _0x1b6d31[_0x19cded(0x157)]({
                        'name': 'cta_copy',
                        'buttonParamsJson': JSON[_0x19cded(0x15e)]({
                            'display_text': '📋\x20ᴄᴏᴘʏ\x20ᴡʜᴏʟᴇ\x20ᴛᴇxᴛ',
                            'id': 'copy_code',
                            'copy_code': _0x13161b
                        })
                    }, {
                        'name': _0x19cded(0x17b),
                        'buttonParamsJson': JSON[_0x19cded(0x15e)]({
                            'display_text': _0x19cded(0x16f),
                            'url': _0x19cded(0x16c)
                        })
                    }, {
                        'name': _0x19cded(0x18a),
                        'buttonParamsJson': JSON[_0x19cded(0x15e)]({
                            'display_text': 'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
                            'id': '.menu'
                        })
                    });
                    let _0x4cd6c4 = generateWAMessageFromContent(_0x3459ea['from'], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto['Message'][_0x19cded(0x184)][_0x19cded(0x171)]({
                                    'body': proto[_0x19cded(0x186)][_0x19cded(0x184)][_0x19cded(0x176)][_0x19cded(0x171)]({ 'text': _0x53c244 }),
                                    'footer': proto[_0x19cded(0x186)][_0x19cded(0x184)][_0x19cded(0x155)][_0x19cded(0x171)]({ 'text': _0x19cded(0x17e) }),
                                    'header': proto[_0x19cded(0x186)]['InteractiveMessage'][_0x19cded(0x177)][_0x19cded(0x171)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x19cded(0x186)][_0x19cded(0x184)][_0x19cded(0x173)][_0x19cded(0x171)]({ 'buttons': _0x1b6d31 })
                                })
                            }
                        }
                    }, {});
                    await _0x5b5451[_0x19cded(0x15c)](_0x4cd6c4[_0x19cded(0x178)][_0x19cded(0x175)], _0x4cd6c4[_0x19cded(0x16b)], { 'messageId': _0x4cd6c4[_0x19cded(0x178)]['id'] }), await _0x3459ea['React']('✅');
                } else
                    throw new Error(_0x19cded(0x189));
            } catch (_0x9f3978) {
                console[_0x19cded(0x185)](_0x19cded(0x15f), _0x9f3978[_0x19cded(0x16b)]), _0x3459ea['reply'](_0x19cded(0x179)), await _0x3459ea[_0x19cded(0x170)]('❌');
            }
        }
    };
export default geminiResponse;

// GIFTED-MD //
