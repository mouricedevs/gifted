function _0x562f() {
    const _0x35f1e8 = [
        '601264GqVawA',
        '_,*\x0a\x20*Gifted-Md\x20is\x20Restarting....*',
        'React',
        '30499sgtFYL',
        'reply',
        '1156160AzmzPa',
        'length',
        'restart',
        '54YuavEg',
        '549624FPOHfG',
        'body',
        '1553048EAeRvz',
        'pushName',
        '2WIMLGF',
        'Hello\x20*_',
        '2764386zQedAF',
        'split',
        '203671UlItTe'
    ];
    _0x562f = function () {
        return _0x35f1e8;
    };
    return _0x562f();
}
(function (_0x14d2a7, _0x2ab4ef) {
    const _0x4e3f21 = _0x2823, _0x3d0b2d = _0x14d2a7();
    while (!![]) {
        try {
            const _0x2d2aab = -parseInt(_0x4e3f21(0x12c)) / 0x1 + -parseInt(_0x4e3f21(0x13a)) / 0x2 * (parseInt(_0x4e3f21(0x136)) / 0x3) + -parseInt(_0x4e3f21(0x12d)) / 0x4 + parseInt(_0x4e3f21(0x132)) / 0x5 + -parseInt(_0x4e3f21(0x135)) / 0x6 * (parseInt(_0x4e3f21(0x130)) / 0x7) + parseInt(_0x4e3f21(0x138)) / 0x8 + parseInt(_0x4e3f21(0x13c)) / 0x9;
            if (_0x2d2aab === _0x2ab4ef)
                break;
            else
                _0x3d0b2d['push'](_0x3d0b2d['shift']());
        } catch (_0x48a6a8) {
            _0x3d0b2d['push'](_0x3d0b2d['shift']());
        }
    }
}(_0x562f, 0x261cd));
function _0x2823(_0x4e90c2, _0x425712) {
    const _0x562fbb = _0x562f();
    return _0x2823 = function (_0x2823de, _0x35f6b6) {
        _0x2823de = _0x2823de - 0x12c;
        let _0x59e127 = _0x562fbb[_0x2823de];
        return _0x59e127;
    }, _0x2823(_0x4e90c2, _0x425712);
}
const restartBot = async _0x2e2154 => {
    const _0x5e6637 = _0x2823, _0x1b7562 = _0x2e2154[_0x5e6637(0x137)]['match'](/^[\\/!#.]/), _0x4a4e6b = _0x1b7562 ? _0x1b7562[0x0] : '/', _0x4271c5 = _0x2e2154[_0x5e6637(0x137)]['startsWith'](_0x4a4e6b) ? _0x2e2154[_0x5e6637(0x137)]['slice'](_0x4a4e6b[_0x5e6637(0x133)])[_0x5e6637(0x13d)]('\x20')[0x0]['toLowerCase']() : '';
    if (_0x4271c5 === _0x5e6637(0x134))
        try {
            await _0x2e2154['reply'](_0x5e6637(0x13b) + _0x2e2154[_0x5e6637(0x139)] + _0x5e6637(0x12e)), process['exit']();
        } catch (_0xb94a85) {
            return console['error'](_0xb94a85), await _0x2e2154[_0x5e6637(0x12f)]('❌'), _0x2e2154[_0x5e6637(0x131)]('An\x20error\x20occurred\x20while\x20restarting\x20the\x20bot:\x20' + _0xb94a85['message']);
        }
};
export default restartBot;
