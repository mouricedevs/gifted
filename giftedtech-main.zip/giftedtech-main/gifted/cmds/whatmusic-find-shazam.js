function _0x5cd5() {
    const _0x11aec2 = [
        'toLowerCase',
        'now',
        'mtype',
        '714420ZJUaBj',
        'unlinkSync',
        '\x0a\x20\x20\x20\x20\x20\x20',
        'trim',
        'name',
        'readFileSync',
        'slice',
        'audioMessage',
        'identify-eu-west-1.acrcloud.com',
        'split',
        '\x0a\x20\x20\x20\x20\x20\x20•\x20👨‍🎤\x20𝙰𝚁𝚃𝙸𝚂𝚃:\x20',
        'videoMessage',
        'join',
        'An\x20Error\x20Occurred\x20While\x20Processing\x20Your\x20Request.',
        '5lxkmXV',
        '\x0a\x20\x20\x20\x20\x20\x20•\x20📆\x20RELEASE\x20DATE:\x20',
        'Identifying\x20the\x20music,\x20please\x20wait...',
        'NOT\x20FOUND',
        '.mp3',
        'includes',
        'mimetype',
        '𝚁𝙴𝚂𝚄𝙻𝚃\x20\x0a\x20\x20\x20\x20\x20\x20•\x20📌\x20*TITLE*:\x20',
        'startsWith',
        'error',
        '6587136aRHyFR',
        'shazam',
        '440296YKJYeY',
        'body',
        'whatmusic',
        'You\x20asked\x20about\x20music.\x20Please\x20provide\x20a\x20quoted\x20audio\x20or\x20video\x20message\x20for\x20identification.',
        '\x0a\x20\x20\x20\x20\x20\x20•\x20🌐\x20𝙶𝙴𝙽𝚁𝙴:\x20',
        'download',
        'reply',
        '716b4ddfa557144ce0a459344fe0c2c9',
        '67809bxMhXP',
        'identify',
        'map',
        '937360uESlGL',
        'status',
        'metadata',
        '1444614AVHFNS',
        '136AevpSm',
        'quoted',
        '91404bYhEdu'
    ];
    _0x5cd5 = function () {
        return _0x11aec2;
    };
    return _0x5cd5();
}
const _0xe8cfc1 = _0x2f2b;
(function (_0x25b951, _0x4b8add) {
    const _0xf68d8f = _0x2f2b, _0x3c51a7 = _0x25b951();
    while (!![]) {
        try {
            const _0x2c0db3 = parseInt(_0xf68d8f(0x155)) / 0x1 + parseInt(_0xf68d8f(0x173)) / 0x2 + parseInt(_0xf68d8f(0x159)) / 0x3 + parseInt(_0xf68d8f(0x14f)) / 0x4 + -parseInt(_0xf68d8f(0x167)) / 0x5 * (-parseInt(_0xf68d8f(0x152)) / 0x6) + -parseInt(_0xf68d8f(0x14c)) / 0x7 * (parseInt(_0xf68d8f(0x153)) / 0x8) + -parseInt(_0xf68d8f(0x171)) / 0x9;
            if (_0x2c0db3 === _0x4b8add)
                break;
            else
                _0x3c51a7['push'](_0x3c51a7['shift']());
        } catch (_0x30fa4d) {
            _0x3c51a7['push'](_0x3c51a7['shift']());
        }
    }
}(_0x5cd5, 0x1f4da));
import _0x26ab5c from 'fs';
import _0x128d20 from 'acrcloud';
function _0x2f2b(_0x587069, _0x11263f) {
    const _0x5cd5d9 = _0x5cd5();
    return _0x2f2b = function (_0x2f2bd9, _0x5a5184) {
        _0x2f2bd9 = _0x2f2bd9 - 0x148;
        let _0x22e60b = _0x5cd5d9[_0x2f2bd9];
        return _0x22e60b;
    }, _0x2f2b(_0x587069, _0x11263f);
}
const acr = new _0x128d20({
        'host': _0xe8cfc1(0x161),
        'access_key': _0xe8cfc1(0x14b),
        'access_secret': 'Lz75UbI8g6AzkLRQgTgHyBlaQq9YT5wonr3xhFkf'
    }), shazam = async (_0x3c91c6, _0x500310) => {
        const _0x5ef0ac = _0xe8cfc1;
        try {
            const _0x1de81a = _0x3c91c6[_0x5ef0ac(0x174)]['match'](/^[\\/!#.]/), _0x5536d0 = _0x1de81a ? _0x1de81a[0x0] : '/', _0x1c72ce = _0x3c91c6[_0x5ef0ac(0x174)][_0x5ef0ac(0x16f)](_0x5536d0) ? _0x3c91c6[_0x5ef0ac(0x174)][_0x5ef0ac(0x15f)](_0x5536d0['length'])[_0x5ef0ac(0x162)]('\x20')[0x0][_0x5ef0ac(0x156)]() : '', _0x2a0c37 = [
                    _0x5ef0ac(0x172),
                    'find',
                    _0x5ef0ac(0x175)
                ];
            if (!_0x2a0c37[_0x5ef0ac(0x16c)](_0x1c72ce))
                return;
            const _0x1fc5c3 = _0x3c91c6[_0x5ef0ac(0x154)] || {};
            if (!_0x1fc5c3 || _0x1fc5c3['mtype'] !== _0x5ef0ac(0x160) && _0x1fc5c3[_0x5ef0ac(0x158)] !== _0x5ef0ac(0x164))
                return _0x3c91c6[_0x5ef0ac(0x14a)](_0x5ef0ac(0x176));
            const _0x1cac26 = _0x3c91c6[_0x5ef0ac(0x154)][_0x5ef0ac(0x16d)];
            try {
                const _0x31967c = await _0x3c91c6[_0x5ef0ac(0x154)][_0x5ef0ac(0x149)](), _0x1901eb = './' + Date[_0x5ef0ac(0x157)]() + _0x5ef0ac(0x16b);
                _0x26ab5c['writeFileSync'](_0x1901eb, _0x31967c), _0x3c91c6['reply'](_0x5ef0ac(0x169));
                const _0x6e2069 = await acr[_0x5ef0ac(0x14d)](_0x26ab5c[_0x5ef0ac(0x15e)](_0x1901eb)), {
                        code: _0x156a0c,
                        msg: _0x1db437
                    } = _0x6e2069[_0x5ef0ac(0x150)];
                if (_0x156a0c !== 0x0)
                    throw new Error(_0x1db437);
                const {
                        title: _0x27cd57,
                        artists: _0x535eb1,
                        album: _0x576a61,
                        genres: _0x30bc3a,
                        release_date: _0x278137
                    } = _0x6e2069[_0x5ef0ac(0x151)]['music'][0x0], _0x32cc3f = (_0x5ef0ac(0x16e) + _0x27cd57 + _0x5ef0ac(0x163) + (_0x535eb1 ? _0x535eb1[_0x5ef0ac(0x14e)](_0x4121d9 => _0x4121d9[_0x5ef0ac(0x15d)])[_0x5ef0ac(0x165)](',\x20') : 'NOT\x20FOUND') + '\x0a\x20\x20\x20\x20\x20\x20•\x20💾\x20𝙰𝙻𝙱𝚄𝙼:\x20' + (_0x576a61 ? _0x576a61[_0x5ef0ac(0x15d)] : 'NOT\x20FOUND') + _0x5ef0ac(0x148) + (_0x30bc3a ? _0x30bc3a[_0x5ef0ac(0x14e)](_0x3b0537 => _0x3b0537[_0x5ef0ac(0x15d)])[_0x5ef0ac(0x165)](',\x20') : _0x5ef0ac(0x16a)) + _0x5ef0ac(0x168) + (_0x278137 || _0x5ef0ac(0x16a)) + _0x5ef0ac(0x15b))[_0x5ef0ac(0x15c)]();
                _0x26ab5c[_0x5ef0ac(0x15a)](_0x1901eb), _0x3c91c6[_0x5ef0ac(0x14a)](_0x32cc3f);
            } catch (_0x1142e7) {
                console[_0x5ef0ac(0x170)](_0x1142e7), _0x3c91c6[_0x5ef0ac(0x14a)]('An\x20error\x20occurred\x20during\x20music\x20identification.');
            }
        } catch (_0x5a8d76) {
            console[_0x5ef0ac(0x170)]('Error:', _0x5a8d76), _0x3c91c6['reply'](_0x5ef0ac(0x166));
        }
    };
export default shazam;
