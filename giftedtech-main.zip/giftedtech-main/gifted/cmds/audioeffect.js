function _0x3e22() {
    const _0x4bd351 = [
        'smooth',
        '=22100\x22',
        '\x22atempo=0.',
        'er=.1:1:64',
        '63,asetrat',
        'atempo=1.0',
        'deep',
        '9rpElkW',
        'audioMessa',
        'LJlyp',
        'DytOX',
        '-filter:a\x20',
        ')*cos(0)\x27:',
        'daVge',
        'EpGjc',
        'blown',
        'includes',
        '-af\x20acrush',
        'DBReW',
        'ou\x20want\x20to',
        'udio.',
        'ffmpeg\x20-i\x20',
        'slow',
        '904092DzZZIQ',
        'Reply\x20to\x20t',
        'writeFileS',
        ':0:log',
        'yZevH',
        '=4/4,asetr',
        'Please\x20wai',
        'th\x20a\x20capti',
        'ile\x20proces',
        'slice',
        'unlinkSync',
        'verse\x22',
        'e=44100\x22',
        '8aPHSBQ',
        'match',
        '-af\x20volume',
        'VedNC',
        'reverse',
        '.mp3',
        'ommand.',
        '-af\x20equali',
        'trim',
        'NiHFb',
        'An\x20error\x20o',
        '60289StKuKG',
        'ccurred\x20wh',
        'startsWith',
        'gzANs',
        'rXFpp',
        'bass',
        '567340tXUkUz',
        'sendMessag',
        '-filter:v\x20',
        'OJHwt',
        'ViYXs',
        'g=20',
        'idth_type=',
        'cnEbz',
        'robot',
        '=12',
        '2/3',
        'fast',
        'de=mci:mc_',
        '-af\x20atempo',
        'on\x20*',
        '6pxnPho',
        'mtype',
        'aWztw',
        'ZvBjY',
        'lrsXW',
        'ate=\x27mi_mo',
        'sing\x20the\x20a',
        'xpeSW',
        '\x22atempo=1.',
        'reply',
        'TwRff',
        'error',
        'readFileSy',
        'ync',
        'body',
        'zer=f=54:w',
        '1562570tYpcvP',
        '\x22minterpol',
        '=65100\x22',
        '-filter_co',
        'toLowerCas',
        'from',
        'o:width=2:',
        'win_size=5',
        '12:overlap',
        'mode=aobmc',
        '\x20change\x20wi',
        'audio/mpeg',
        'fat',
        ')\x27:imag=\x27h',
        'mdTxk',
        'fEwvI',
        'IUOFm',
        't...',
        'hCgYu',
        'KoFBJ',
        'cmvxJ',
        '=0.75\x22',
        'length',
        'ypot(re,im',
        'tfilt=real',
        '=44100*1.2',
        'download',
        'CHYrq',
        'FbGSs',
        '6457448aaUvKd',
        '=44100\x22',
        'sing\x20the\x20c',
        'he\x20audio\x20y',
        'CUVsI',
        '5,asetrate',
        'YVbzu',
        'mplex\x20\x22are',
        'Error:',
        'nzMEy',
        'tupai',
        ',im)*sin(0',
        '.webm',
        ':vsbmc=1:f',
        'zGVLv',
        'ps=120\x27\x22',
        '2514930jjcsBb',
        'SuKdz',
        'StlMf',
        'earrape',
        'gsIKY',
        '6FYAgnG',
        'mplex\x20\x22aff',
        'EBmEl',
        '=\x27hypot(re',
        'tCiiT',
        '6,asetrate',
        'bhApr',
        'ate=44500*',
        'split',
        '7,asetrate',
        'YHHLO',
        'quoted',
        'nightcore',
        'gvjfo',
        'VHbhg',
        '4234573BMgetc'
    ];
    _0x3e22 = function () {
        return _0x4bd351;
    };
    return _0x3e22();
}
(function (_0x2110c1, _0x283b2f) {
    const _0x13375c = _0x1b4f, _0x11c7cb = _0x2110c1();
    while (!![]) {
        try {
            const _0x58f1bc = parseInt(_0x13375c(0x154)) / (0x1b49 + -0x67a + -0x1 * 0x14ce) * (parseInt(_0x13375c(0x169)) / (-0x24ff + -0x73 * 0x37 + -0x1 * -0x3db6)) + -parseInt(_0x13375c(0x13c)) / (-0x1773 * -0x1 + 0x1898 + 0xd4 * -0x3a) + parseInt(_0x13375c(0x149)) / (0x1e93 + -0xe5 + -0xed5 * 0x2) * (-parseInt(_0x13375c(0x179)) / (-0x1 * -0xe21 + -0xf * -0xa1 + -0x178b)) + parseInt(_0x13375c(0x115)) / (0xee * 0x5 + -0x1 * -0x229f + -0x273f * 0x1) * (parseInt(_0x13375c(0x124)) / (-0x12c8 + -0x1a5 * -0x7 + 0x74c)) + -parseInt(_0x13375c(0x100)) / (0x23d8 + 0x1e17 + -0x41e7 * 0x1) * (-parseInt(_0x13375c(0x12c)) / (-0x1 * 0x23ce + 0x1474 * -0x1 + 0x384b)) + parseInt(_0x13375c(0x15a)) / (-0x14dd + 0x167f + -0x198) + -parseInt(_0x13375c(0x110)) / (0x167 * -0x3 + -0x10 * -0x11 + -0x33 * -0x10);
            if (_0x58f1bc === _0x283b2f)
                break;
            else
                _0x11c7cb['push'](_0x11c7cb['shift']());
        } catch (_0x332618) {
            _0x11c7cb['push'](_0x11c7cb['shift']());
        }
    }
}(_0x3e22, 0x11771 * -0x1 + -0x7 * 0x5d13 + -0x19 * -0x7289));
function _0x1b4f(_0x42c9d7, _0x57efc0) {
    const _0x2ef779 = _0x3e22();
    return _0x1b4f = function (_0x45a3ff, _0x468644) {
        _0x45a3ff = _0x45a3ff - (-0xc * 0xc5 + 0x1516 + 0x1 * -0xaee);
        let _0xbd2225 = _0x2ef779[_0x45a3ff];
        return _0xbd2225;
    }, _0x1b4f(_0x42c9d7, _0x57efc0);
}
import { exec } from 'child_process';
import _0x2a3dd5 from 'fs';
import { getRandom } from '../../gift/gifted.cjs';
const audioEffects = async (_0x226857, _0x32eec1) => {
    const _0x599af9 = _0x1b4f, _0x120437 = {
            'cmvxJ': _0x599af9(0x108),
            'SuKdz': _0x599af9(0x153) + _0x599af9(0x155) + _0x599af9(0x144) + _0x599af9(0x16f) + _0x599af9(0x139),
            'TwRff': _0x599af9(0xee),
            'EBmEl': function (_0x3031ee, _0x38e6f4) {
                return _0x3031ee + _0x38e6f4;
            },
            'xpeSW': _0x599af9(0x159),
            'nzMEy': _0x599af9(0x134),
            'lrsXW': _0x599af9(0x12b),
            'YHHLO': _0x599af9(0x113),
            'gvjfo': _0x599af9(0x165),
            'CUVsI': _0x599af9(0xef),
            'YVbzu': _0x599af9(0x121),
            'KoFBJ': _0x599af9(0x14d),
            'DBReW': _0x599af9(0x162),
            'FbGSs': _0x599af9(0x13b),
            'ZvBjY': _0x599af9(0x125),
            'IUOFm': _0x599af9(0x10a),
            'LJlyp': function (_0x571056, _0x5d9866) {
                return _0x571056 === _0x5d9866;
            },
            'rXFpp': _0x599af9(0x150) + _0x599af9(0x178) + _0x599af9(0x160) + _0x599af9(0x17f) + _0x599af9(0x15f),
            'gzANs': function (_0x1f05a3, _0x579ad2) {
                return _0x1f05a3 === _0x579ad2;
            },
            'hCgYu': _0x599af9(0x136) + _0x599af9(0x128) + _0x599af9(0x13f),
            'cnEbz': function (_0x703d3c, _0x315070) {
                return _0x703d3c === _0x315070;
            },
            'VedNC': _0x599af9(0x167) + _0x599af9(0x141) + _0x599af9(0x11c) + _0x599af9(0x164),
            'mdTxk': _0x599af9(0x14b) + _0x599af9(0x163),
            'NiHFb': _0x599af9(0x130) + _0x599af9(0x171) + _0x599af9(0x129) + _0x599af9(0x148),
            'fEwvI': _0x599af9(0x130) + _0x599af9(0x171) + _0x599af9(0x11a) + _0x599af9(0x126),
            'zGVLv': _0x599af9(0x130) + _0x599af9(0x12a) + _0x599af9(0x11a) + _0x599af9(0xfc) + '5',
            'daVge': _0x599af9(0x17c) + _0x599af9(0x107) + _0x599af9(0x147),
            'aWztw': _0x599af9(0x17c) + _0x599af9(0x116) + _0x599af9(0xfb) + _0x599af9(0x118) + _0x599af9(0x10b) + _0x599af9(0xf0) + _0x599af9(0xfa) + _0x599af9(0x131) + _0x599af9(0x180) + _0x599af9(0x181) + _0x599af9(0xf8),
            'tCiiT': _0x599af9(0x130) + _0x599af9(0x127) + _0x599af9(0x11e) + _0x599af9(0x101),
            'ViYXs': _0x599af9(0x15c) + _0x599af9(0x17a) + _0x599af9(0x16e) + _0x599af9(0x166) + _0x599af9(0xec) + _0x599af9(0x10d) + _0x599af9(0x10f),
            'OJHwt': _0x599af9(0x130) + _0x599af9(0x127) + _0x599af9(0x105) + _0x599af9(0x17b),
            'gsIKY': function (_0x107777, _0x5b110c) {
                return _0x107777 !== _0x5b110c;
            },
            'EpGjc': _0x599af9(0x12d) + 'ge',
            'CHYrq': _0x599af9(0x142) + _0x599af9(0xf4),
            'StlMf': function (_0x23fa7f, _0xbb49c3) {
                return _0x23fa7f(_0xbb49c3);
            },
            'yZevH': _0x599af9(0x10c),
            'DytOX': _0x599af9(0x14e),
            'VHbhg': function (_0x17a009, _0xde0618, _0x273401) {
                return _0x17a009(_0xde0618, _0x273401);
            },
            'bhApr': _0x599af9(0x153) + _0x599af9(0x155) + _0x599af9(0x144) + _0x599af9(0x102) + _0x599af9(0x14f)
        };
    try {
        const _0x354338 = _0x226857[_0x599af9(0x177)][_0x599af9(0x14a)](/^[\\/!#.]/), _0x5445fb = _0x354338 ? _0x354338[-0x5 * -0x73b + -0x3 * 0x9fb + 0x13e * -0x5] : '/', _0x173fe0 = _0x226857[_0x599af9(0x177)][_0x599af9(0x156)](_0x5445fb) ? _0x226857[_0x599af9(0x177)][_0x599af9(0x145)](_0x5445fb[_0x599af9(0xf9)])[_0x599af9(0x11d)]('\x20')[0x7c5 * -0x1 + 0x154f + -0xd8a][_0x599af9(0x17d) + 'e']() : '', _0x228b3e = _0x226857[_0x599af9(0x177)][_0x599af9(0x145)](_0x120437[_0x599af9(0x117)](_0x5445fb[_0x599af9(0xf9)], _0x173fe0[_0x599af9(0xf9)]))[_0x599af9(0x151)](), _0xeea320 = [
                _0x120437[_0x599af9(0x170)],
                _0x120437[_0x599af9(0x109)],
                _0x120437[_0x599af9(0x16d)],
                _0x120437[_0x599af9(0x11f)],
                _0x120437[_0x599af9(0x122)],
                _0x120437[_0x599af9(0x104)],
                _0x120437[_0x599af9(0x106)],
                _0x120437[_0x599af9(0xf6)],
                _0x120437[_0x599af9(0x137)],
                _0x120437[_0x599af9(0xff)],
                _0x120437[_0x599af9(0x16c)],
                _0x120437[_0x599af9(0xf3)]
            ];
        if (!_0xeea320[_0x599af9(0x135)](_0x173fe0))
            return;
        let _0x46e8f7;
        if (_0x120437[_0x599af9(0x12e)](_0x173fe0, _0x120437[_0x599af9(0x170)]))
            _0x46e8f7 = _0x120437[_0x599af9(0x158)];
        else {
            if (_0x120437[_0x599af9(0x157)](_0x173fe0, _0x120437[_0x599af9(0x109)]))
                _0x46e8f7 = _0x120437[_0x599af9(0xf5)];
            else {
                if (_0x120437[_0x599af9(0x161)](_0x173fe0, _0x120437[_0x599af9(0x16d)]))
                    _0x46e8f7 = _0x120437[_0x599af9(0x14c)];
                else {
                    if (_0x120437[_0x599af9(0x161)](_0x173fe0, _0x120437[_0x599af9(0x11f)]))
                        _0x46e8f7 = _0x120437[_0x599af9(0xf1)];
                    else {
                        if (_0x120437[_0x599af9(0x157)](_0x173fe0, _0x120437[_0x599af9(0x122)]))
                            _0x46e8f7 = _0x120437[_0x599af9(0x152)];
                        else {
                            if (_0x120437[_0x599af9(0x12e)](_0x173fe0, _0x120437[_0x599af9(0x104)]))
                                _0x46e8f7 = _0x120437[_0x599af9(0xf2)];
                            else {
                                if (_0x120437[_0x599af9(0x157)](_0x173fe0, _0x120437[_0x599af9(0x106)]))
                                    _0x46e8f7 = _0x120437[_0x599af9(0x10e)];
                                else {
                                    if (_0x120437[_0x599af9(0x161)](_0x173fe0, _0x120437[_0x599af9(0xf6)]))
                                        _0x46e8f7 = _0x120437[_0x599af9(0x132)];
                                    else {
                                        if (_0x120437[_0x599af9(0x161)](_0x173fe0, _0x120437[_0x599af9(0x137)]))
                                            _0x46e8f7 = _0x120437[_0x599af9(0x16b)];
                                        else {
                                            if (_0x120437[_0x599af9(0x161)](_0x173fe0, _0x120437[_0x599af9(0xff)]))
                                                _0x46e8f7 = _0x120437[_0x599af9(0x119)];
                                            else {
                                                if (_0x120437[_0x599af9(0x12e)](_0x173fe0, _0x120437[_0x599af9(0x16c)]))
                                                    _0x46e8f7 = _0x120437[_0x599af9(0x15e)];
                                                else
                                                    _0x120437[_0x599af9(0x12e)](_0x173fe0, _0x120437[_0x599af9(0xf3)]) && (_0x46e8f7 = _0x120437[_0x599af9(0x15d)]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!_0x226857[_0x599af9(0x120)] || _0x120437[_0x599af9(0x114)](_0x226857[_0x599af9(0x120)][_0x599af9(0x16a)], _0x120437[_0x599af9(0x133)]))
            return _0x226857[_0x599af9(0x172)](_0x599af9(0x13d) + _0x599af9(0x103) + _0x599af9(0x138) + _0x599af9(0xed) + _0x599af9(0x143) + _0x599af9(0x168) + _0x120437[_0x599af9(0x117)](_0x5445fb, _0x173fe0) + '*');
        _0x226857[_0x599af9(0x172)](_0x120437[_0x599af9(0xfe)]);
        const _0x385d3c = await _0x226857[_0x599af9(0x120)][_0x599af9(0xfd)](), _0x606d5 = './' + _0x120437[_0x599af9(0x112)](getRandom, _0x120437[_0x599af9(0x140)]);
        _0x2a3dd5[_0x599af9(0x13e) + _0x599af9(0x176)](_0x606d5, _0x385d3c);
        const _0x5163a6 = './' + _0x120437[_0x599af9(0x112)](getRandom, _0x120437[_0x599af9(0x12f)]);
        _0x120437[_0x599af9(0x123)](exec, _0x599af9(0x13a) + _0x606d5 + '\x20' + _0x46e8f7 + '\x20' + _0x5163a6, (_0x6d4e79, _0x11bb7b, _0x5d1965) => {
            const _0x11f06c = _0x599af9;
            _0x2a3dd5[_0x11f06c(0x146)](_0x606d5);
            if (_0x6d4e79)
                return console[_0x11f06c(0x174)](_0x120437[_0x11f06c(0xf7)], _0x6d4e79), _0x226857[_0x11f06c(0x172)](_0x120437[_0x11f06c(0x111)]);
            const _0x593db2 = _0x2a3dd5[_0x11f06c(0x175) + 'nc'](_0x5163a6);
            _0x32eec1[_0x11f06c(0x15b) + 'e'](_0x226857[_0x11f06c(0x17e)], {
                'audio': _0x593db2,
                'mimetype': _0x120437[_0x11f06c(0x173)]
            }, { 'quoted': _0x226857 }), _0x2a3dd5[_0x11f06c(0x146)](_0x5163a6);
        });
    } catch (_0x3f642b) {
        console[_0x599af9(0x174)](_0x120437[_0x599af9(0xf7)], _0x3f642b), _0x226857[_0x599af9(0x172)](_0x120437[_0x599af9(0x11b)]);
    }
};
export default audioEffects;
