function _0x1c2a() {
    const _0x61016b = [
        'startsWith',
        '176XIJyIF',
        'data',
        '313803obfUMw',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕𝟓*',
        'status',
        '?text=',
        'lifebuoys',
        'blood',
        'body',
        '\x20logo:',
        '*Example\x20Usage:*\x20.deadpool\x20Gifted|Tech',
        '&apikey=',
        '261863XpBlVm',
        'avenger',
        '170dUqFCI',
        'multicolor',
        'https://api.neoxr.eu/api/lifebuoys?text1=',
        'eraser',
        '12SkXkLE',
        'deadpool',
        'Failed\x20with\x20error\x20from\x20Gifted\x20API.\x20Please\x20try\x20again\x20later.',
        '*Example\x20Usage:*\x20.marvel\x20Gifted|Tech',
        '672650GfiPtm',
        '476622BqmwZs',
        'breakwall',
        'papercut',
        '*Example\x20Usage:*\x20.avenger\x20Gifted|Tech',
        'glow',
        'blackink',
        'glasses',
        'matrix',
        '*Example\x20Usage*:\x20.glow\x20Gifted\x20Tech',
        '\x20Gifted\x20Tech',
        'https://api.neoxr.eu/api/pornhub?text1=',
        'pig',
        'A\x20Moment,\x20\x20*Gifted-Md*\x20is\x20Generating\x20Your\x20Logo...',
        'captain',
        '*Example\x20Usage:*\x20.lifebuoys\x20Gifted|Tech',
        '*Example\x20Usage:*\x20.pornhub\x20Gifted|Tech',
        'joker',
        'React',
        'Both\x20text1\x20and\x20text2\x20are\x20required\x20for\x20the\x20lifebuoys\x20command.',
        'neon',
        'Both\x20text1\x20and\x20text2\x20are\x20required\x20for\x20the\x20deadpool\x20command.',
        'length',
        '&text2=',
        'Both\x20text1\x20and\x20text2\x20are\x20required\x20for\x20the\x20pornhub\x20command.',
        'from',
        '*Example\x20Usage:*\x20.',
        'grass',
        'split',
        'gradient',
        'slice',
        'sendMessage',
        'Here\x27s\x20your\x20',
        'mcandy',
        'error',
        '285316NjBSdG',
        'marvel',
        'Invalid\x20response\x20from\x20the\x20API.',
        'glitch',
        'trim',
        '1397696sfqSDM',
        '2206878vVkVyg',
        'match',
        'https://api.neoxr.eu/api/',
        'url',
        'includes',
        'flames',
        'clouds',
        'https://api.neoxr.eu/api/marvel?text1=',
        'reply',
        'pornhub',
        'Both\x20text1\x20and\x20text2\x20are\x20required\x20for\x20the\x20avenger\x20command.',
        'json',
        'typography'
    ];
    _0x1c2a = function () {
        return _0x61016b;
    };
    return _0x1c2a();
}
(function (_0x37adc4, _0x1b0105) {
    const _0x3c8fe9 = _0x58df, _0x36e6d7 = _0x37adc4();
    while (!![]) {
        try {
            const _0x30b479 = parseInt(_0x3c8fe9(0xb8)) / 0x1 + parseInt(_0x3c8fe9(0xbd)) / 0x2 + parseInt(_0x3c8fe9(0xe3)) / 0x3 * (-parseInt(_0x3c8fe9(0xde)) / 0x4) + parseInt(_0x3c8fe9(0xe2)) / 0x5 + -parseInt(_0x3c8fe9(0xbe)) / 0x6 + -parseInt(_0x3c8fe9(0xd8)) / 0x7 * (-parseInt(_0x3c8fe9(0xcc)) / 0x8) + parseInt(_0x3c8fe9(0xce)) / 0x9 * (-parseInt(_0x3c8fe9(0xda)) / 0xa);
            if (_0x30b479 === _0x1b0105)
                break;
            else
                _0x36e6d7['push'](_0x36e6d7['shift']());
        } catch (_0x499ef6) {
            _0x36e6d7['push'](_0x36e6d7['shift']());
        }
    }
}(_0x1c2a, 0x7b2c6));
import _0x472111 from 'node-fetch';
const LogoCommand = async (_0x5c50db, _0x3facd2) => {
    const _0x4ff8cd = _0x58df, _0x2f8716 = _0x4ff8cd(0xb6), _0x3db4c4 = _0x5c50db[_0x4ff8cd(0xd4)][_0x4ff8cd(0xbf)](/^[\\/!#.]/), _0x262621 = _0x3db4c4 ? _0x3db4c4[0x0] : '/', _0x2c433e = _0x5c50db[_0x4ff8cd(0xd4)][_0x4ff8cd(0xcb)](_0x262621) ? _0x5c50db[_0x4ff8cd(0xd4)][_0x4ff8cd(0xb3)](_0x262621[_0x4ff8cd(0xab)])[_0x4ff8cd(0xb1)]('\x20')[0x0]['toLowerCase']() : '', _0x2a5f70 = _0x5c50db[_0x4ff8cd(0xd4)][_0x4ff8cd(0xb3)](_0x262621[_0x4ff8cd(0xab)] + _0x2c433e[_0x4ff8cd(0xab)])[_0x4ff8cd(0xbc)](), _0x5921d0 = [
            'avenger',
            'glow',
            _0x4ff8cd(0xe8),
            _0x4ff8cd(0xd3),
            _0x4ff8cd(0xe4),
            'cake',
            _0x4ff8cd(0xf0),
            _0x4ff8cd(0xc4),
            'deadpool',
            _0x4ff8cd(0xdd),
            _0x4ff8cd(0xc3),
            _0x4ff8cd(0xe9),
            _0x4ff8cd(0xbb),
            _0x4ff8cd(0xb2),
            _0x4ff8cd(0xb0),
            _0x4ff8cd(0xf3),
            'lifebuoys',
            _0x4ff8cd(0xea),
            _0x4ff8cd(0xb9),
            _0x4ff8cd(0xdb),
            'naruto',
            _0x4ff8cd(0xa9),
            _0x4ff8cd(0xe5),
            _0x4ff8cd(0xee),
            _0x4ff8cd(0xc7),
            'puppy',
            'sand',
            _0x4ff8cd(0xb3),
            'sunset',
            _0x4ff8cd(0xca)
        ];
    if (_0x5921d0[_0x4ff8cd(0xc2)](_0x2c433e)) {
        let _0x1c4548 = '';
        if (_0x2c433e === _0x4ff8cd(0xd9)) {
            if (!_0x2a5f70['includes']('|')) {
                await _0x5c50db['reply'](_0x4ff8cd(0xe6));
                return;
            }
            const [_0x282941, _0x4c842b] = _0x2a5f70[_0x4ff8cd(0xb1)]('|');
            if (!_0x282941 || !_0x4c842b) {
                await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xc8));
                return;
            }
            _0x1c4548 = 'https://api.neoxr.eu/api/avenger?text1=' + encodeURIComponent(_0x282941) + _0x4ff8cd(0xac) + encodeURIComponent(_0x4c842b) + _0x4ff8cd(0xd7) + _0x2f8716;
        } else {
            if (_0x2c433e === _0x4ff8cd(0xe7)) {
                if (!_0x2a5f70) {
                    await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xeb));
                    return;
                }
                _0x1c4548 = 'https://api.neoxr.eu/api/glow?text=' + encodeURIComponent(_0x2a5f70) + '&apikey=' + _0x2f8716;
            } else {
                if (_0x2c433e === _0x4ff8cd(0xdf)) {
                    if (!_0x2a5f70['includes']('|')) {
                        await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xd6));
                        return;
                    }
                    const [_0x56f2a4, _0x190185] = _0x2a5f70['split']('|');
                    if (!_0x56f2a4 || !_0x190185) {
                        await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xaa));
                        return;
                    }
                    _0x1c4548 = 'https://api.neoxr.eu/api/deadpool?text1=' + encodeURIComponent(_0x56f2a4) + _0x4ff8cd(0xac) + encodeURIComponent(_0x190185) + _0x4ff8cd(0xd7) + _0x2f8716;
                } else {
                    if (_0x2c433e === _0x4ff8cd(0xd2)) {
                        if (!_0x2a5f70[_0x4ff8cd(0xc2)]('|')) {
                            await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xf1));
                            return;
                        }
                        const [_0x50bc15, _0x26b041] = _0x2a5f70['split']('|');
                        if (!_0x50bc15 || !_0x26b041) {
                            await _0x5c50db['reply'](_0x4ff8cd(0xa8));
                            return;
                        }
                        _0x1c4548 = _0x4ff8cd(0xdc) + encodeURIComponent(_0x50bc15) + _0x4ff8cd(0xac) + encodeURIComponent(_0x26b041) + _0x4ff8cd(0xd7) + _0x2f8716;
                    } else {
                        if (_0x2c433e === _0x4ff8cd(0xb9)) {
                            if (!_0x2a5f70[_0x4ff8cd(0xc2)]('|')) {
                                await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xe1));
                                return;
                            }
                            const [_0xe9dd89, _0x5680d3] = _0x2a5f70['split']('|');
                            if (!_0xe9dd89 || !_0x5680d3) {
                                await _0x5c50db[_0x4ff8cd(0xc6)]('Both\x20text1\x20and\x20text2\x20are\x20required\x20for\x20the\x20marvel\x20command.');
                                return;
                            }
                            _0x1c4548 = _0x4ff8cd(0xc5) + encodeURIComponent(_0xe9dd89) + _0x4ff8cd(0xac) + encodeURIComponent(_0x5680d3) + '&apikey=' + _0x2f8716;
                        } else {
                            if (_0x2c433e === 'pornhub') {
                                if (!_0x2a5f70['includes']('|')) {
                                    await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xf2));
                                    return;
                                }
                                const [_0x8aa263, _0xa2fe3e] = _0x2a5f70['split']('|');
                                if (!_0x8aa263 || !_0xa2fe3e) {
                                    await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xad));
                                    return;
                                }
                                _0x1c4548 = _0x4ff8cd(0xed) + encodeURIComponent(_0x8aa263) + '&text2=' + encodeURIComponent(_0xa2fe3e) + _0x4ff8cd(0xd7) + _0x2f8716;
                            } else {
                                if (!_0x2a5f70) {
                                    await _0x5c50db['reply'](_0x4ff8cd(0xaf) + _0x2c433e + _0x4ff8cd(0xec));
                                    return;
                                }
                                _0x1c4548 = _0x4ff8cd(0xc0) + _0x2c433e + _0x4ff8cd(0xd1) + encodeURIComponent(_0x2a5f70) + _0x4ff8cd(0xd7) + _0x2f8716;
                            }
                        }
                    }
                }
            }
        }
        try {
            await _0x5c50db[_0x4ff8cd(0xf4)]('🕘'), await _0x5c50db['reply'](_0x4ff8cd(0xef));
            const _0x327fb9 = await _0x472111(_0x1c4548), _0x25ac9e = await _0x327fb9[_0x4ff8cd(0xc9)]();
            if (_0x25ac9e[_0x4ff8cd(0xd0)] && _0x25ac9e[_0x4ff8cd(0xcd)] && _0x25ac9e[_0x4ff8cd(0xcd)][_0x4ff8cd(0xc1)]) {
                const _0x1ca4a1 = _0x25ac9e['data'][_0x4ff8cd(0xc1)];
                await _0x5c50db[_0x4ff8cd(0xc6)](_0x4ff8cd(0xb5) + _0x2c433e + _0x4ff8cd(0xd5)), await _0x3facd2[_0x4ff8cd(0xb4)](_0x5c50db[_0x4ff8cd(0xae)], {
                    'image': { 'url': _0x1ca4a1 },
                    'caption': _0x4ff8cd(0xcf)
                });
            } else
                throw new Error(_0x4ff8cd(0xba));
            await _0x5c50db[_0x4ff8cd(0xf4)]('✅');
        } catch (_0x257305) {
            console[_0x4ff8cd(0xb7)]('Error\x20from\x20Gifted\x20API:', _0x257305), await _0x3facd2[_0x4ff8cd(0xb4)](_0x5c50db[_0x4ff8cd(0xae)], { 'text': _0x4ff8cd(0xe0) });
        }
    }
};
function _0x58df(_0x3a3a53, _0x6af058) {
    const _0x1c2a02 = _0x1c2a();
    return _0x58df = function (_0x58dfc9, _0x48b9d4) {
        _0x58dfc9 = _0x58dfc9 - 0xa8;
        let _0x5d6520 = _0x1c2a02[_0x58dfc9];
        return _0x5d6520;
    }, _0x58df(_0x3a3a53, _0x6af058);
}
export default LogoCommand;
