function _0x48a2(_0x5f58df, _0x8ca73b) {
    const _0x3ce2e9 = _0x3ce2();
    return _0x48a2 = function (_0x48a2d6, _0x33803d) {
        _0x48a2d6 = _0x48a2d6 - 0x1b2;
        let _0x589c8b = _0x3ce2e9[_0x48a2d6];
        return _0x589c8b;
    }, _0x48a2(_0x5f58df, _0x8ca73b);
}
function _0x3ce2() {
    const _0x5add11 = [
        'A\x20Moment,*Gifted-Md*\x20is\x20Compiling\x20Contacts,\x20Please\x20Wait...',
        'includes',
        'message',
        '925430JwUcUE',
        'sendMessage',
        '1788eebkHN',
        'vcf',
        'error',
        'match',
        'React',
        '64Qwwbtx',
        'split',
        'text/x-vcard',
        '76ANVDrx',
        '\x20Contacts*',
        '266635lXdvKK',
        'contacts',
        'Total\x20number\x20of\x20contacts\x20saved:\x20*',
        'groupMetadata',
        '*\x0aGroup\x20contacts\x20saved\x20successfully.\x20Feel\x20free\x20to\x20import\x20the\x20vcf\x20file.',
        '4012yGORBT',
        '440NLjbJd',
        'VCF\x20FOR:\x20*',
        '362574otHxOk',
        '4468764XISirP',
        'This\x20command\x20can\x20only\x20be\x20used\x20in\x20group\x20chats.',
        'Gifted\x20',
        'toLowerCase',
        '7BWuPdT',
        '130713uIDkoj',
        'startsWith',
        'reply',
        '\x0aBEGIN:VCARD\x0aVERSION:3.0\x0aFN:',
        'contacts.vcf',
        'No\x20participants\x20found\x20in\x20this\x20group.',
        'body',
        'isGroup',
        'from',
        'slice',
        'forEach',
        'participants',
        'vcard',
        '.vcf',
        '74745KSDSnJ',
        'length'
    ];
    _0x3ce2 = function () {
        return _0x5add11;
    };
    return _0x3ce2();
}
(function (_0x416894, _0x3b70f0) {
    const _0x289a23 = _0x48a2, _0x1cb071 = _0x416894();
    while (!![]) {
        try {
            const _0x49b2e2 = -parseInt(_0x289a23(0x1b3)) / 0x1 * (parseInt(_0x289a23(0x1d6)) / 0x2) + parseInt(_0x289a23(0x1b6)) / 0x3 + parseInt(_0x289a23(0x1d9)) / 0x4 * (-parseInt(_0x289a23(0x1db)) / 0x5) + -parseInt(_0x289a23(0x1b7)) / 0x6 * (parseInt(_0x289a23(0x1bb)) / 0x7) + -parseInt(_0x289a23(0x1b4)) / 0x8 * (-parseInt(_0x289a23(0x1ca)) / 0x9) + parseInt(_0x289a23(0x1cf)) / 0xa + -parseInt(_0x289a23(0x1bc)) / 0xb * (-parseInt(_0x289a23(0x1d1)) / 0xc);
            if (_0x49b2e2 === _0x3b70f0)
                break;
            else
                _0x1cb071['push'](_0x1cb071['shift']());
        } catch (_0x35de91) {
            _0x1cb071['push'](_0x1cb071['shift']());
        }
    }
}(_0x3ce2, 0x87570));
import { writeFileSync } from 'fs';
const saveContact = async (_0x5b6c60, _0x40d3c8) => {
    const _0x59c4ed = _0x48a2, _0x31b039 = _0x5b6c60[_0x59c4ed(0x1c2)][_0x59c4ed(0x1d4)](/^[\\/!#.]/), _0x51ac93 = _0x31b039 ? _0x31b039[0x0] : '/', _0x2efd18 = _0x5b6c60[_0x59c4ed(0x1c2)][_0x59c4ed(0x1bd)](_0x51ac93) ? _0x5b6c60[_0x59c4ed(0x1c2)][_0x59c4ed(0x1c5)](_0x51ac93[_0x59c4ed(0x1cb)])[_0x59c4ed(0x1d7)]('\x20')[0x0][_0x59c4ed(0x1ba)]() : '', _0x7514c5 = [
            _0x59c4ed(0x1d2),
            _0x59c4ed(0x1dc),
            _0x59c4ed(0x1c8),
            'savecontact'
        ];
    if (_0x7514c5[_0x59c4ed(0x1cd)](_0x2efd18))
        try {
            await _0x5b6c60[_0x59c4ed(0x1d5)]('🕘'), await _0x5b6c60[_0x59c4ed(0x1be)](_0x59c4ed(0x1cc));
            if (!_0x5b6c60[_0x59c4ed(0x1c3)])
                return _0x5b6c60['reply'](_0x59c4ed(0x1b8));
            const _0x4d40ad = await _0x40d3c8[_0x59c4ed(0x1de)](_0x5b6c60[_0x59c4ed(0x1c4)]), _0xe0dc4b = _0x4d40ad[_0x59c4ed(0x1c7)], _0x122498 = _0x4d40ad['subject'];
            if (!_0xe0dc4b || _0xe0dc4b[_0x59c4ed(0x1cb)] === 0x0)
                return _0x5b6c60[_0x59c4ed(0x1be)](_0x59c4ed(0x1c1));
            let _0x2f56f5 = '';
            _0xe0dc4b[_0x59c4ed(0x1c6)]((_0x49048d, _0x5e618f) => {
                const _0x56b747 = _0x59c4ed, _0x24e71a = _0x56b747(0x1b9) + (_0x5e618f + 0x1) || _0x56b747(0x1b9) + (_0x5e618f + 0x1), _0x59c64a = _0x49048d['id'][_0x56b747(0x1d7)]('@')[0x0];
                _0x2f56f5 += _0x56b747(0x1bf) + _0x24e71a + '\x0aTEL;TYPE=CELL:' + _0x59c64a + '\x0aEND:VCARD\x0a';
            });
            const _0x5a306d = _0x59c4ed(0x1c0);
            writeFileSync(_0x5a306d, _0x2f56f5), await _0x40d3c8[_0x59c4ed(0x1d0)](_0x5b6c60['from'], {
                'document': { 'url': './' + _0x5a306d },
                'mimetype': _0x59c4ed(0x1d8),
                'fileName': _0x122498 + _0x59c4ed(0x1c9),
                'caption': _0x59c4ed(0x1b5) + _0x122498 + _0x59c4ed(0x1b2)
            }, { 'quoted': _0x5b6c60 });
            const _0x59da12 = _0xe0dc4b[_0x59c4ed(0x1cb)];
            await _0x5b6c60[_0x59c4ed(0x1be)](_0x59c4ed(0x1dd) + _0x59da12 + _0x59c4ed(0x1da)), await _0x5b6c60['React']('✅'), await _0x5b6c60['reply']('Success...');
        } catch (_0x31de7d) {
            console[_0x59c4ed(0x1d3)]('Error\x20saving\x20contacts:', _0x31de7d[_0x59c4ed(0x1ce)]), await _0x5b6c60[_0x59c4ed(0x1be)]('Error\x20saving\x20contacts:\x20' + _0x31de7d[_0x59c4ed(0x1ce)]), await _0x5b6c60['React']('❌');
        }
};
export default saveContact;
